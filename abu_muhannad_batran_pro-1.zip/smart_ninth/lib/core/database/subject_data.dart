import '../../features/subjects/domain/subject.dart';

/// بيانات أولية للواجهة. يمكن لاحقاً إضافة الدروس المستخرجة من الكتب المدرسية.
const List<Subject> subjects = [
  Subject(name: 'الرياضيات - الجبر', icon: 'calculate', colorValue: 0xFF3F7CAC),
  Subject(name: 'الرياضيات - الهندسة', icon: 'shapes', colorValue: 0xFF7B61A8),
  Subject(name: 'اللغة العربية', icon: 'menu_book', colorValue: 0xFFB7791F),
  Subject(name: 'اللغة الإنكليزية', icon: 'language', colorValue: 0xFF168C83),
  Subject(name: 'الفيزياء والكيمياء', icon: 'science', colorValue: 0xFFD15A5A),
  Subject(name: 'علم الأحياء والأرض', icon: 'biotech', colorValue: 0xFF4D8B55),
  Subject(name: 'التاريخ', icon: 'history_edu', colorValue: 0xFF946B4B),
  Subject(name: 'الجغرافيا', icon: 'public', colorValue: 0xFF398A9C),
];
