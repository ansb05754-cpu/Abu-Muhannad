class AppConstants {
  static const appName = 'أبو مهند البطران';
  static const gradeName = 'الصف التاسع الأساسي';
  static const welcome = 'خطوتك الأولى نحو التفوق';
}
