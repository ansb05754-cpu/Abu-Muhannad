import 'package:flutter/material.dart';
import '../features/home/presentation/home_screen.dart';
import '../features/subjects/presentation/subjects_screen.dart';
import '../features/lessons/presentation/lessons_screen.dart';

class AppRoutes {
  static const home = '/';
  static const subjects = '/subjects';
  static const lessons = '/lessons';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
      case subjects:
        return MaterialPageRoute(builder: (_) => const SubjectsScreen());
      case lessons:
        final subject = settings.arguments as String? ?? 'المادة';
        return MaterialPageRoute(builder: (_) => LessonsScreen(subjectName: subject));
      default:
        return MaterialPageRoute(builder: (_) => const HomeScreen());
    }
  }
}
