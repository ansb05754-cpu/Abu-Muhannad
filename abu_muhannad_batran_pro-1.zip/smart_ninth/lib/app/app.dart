import 'package:flutter/material.dart';
import 'routes.dart';
import 'theme.dart';

class AbuMuhannadApp extends StatelessWidget {
  const AbuMuhannadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'أبو مهند البطران',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      initialRoute: AppRoutes.home,
      onGenerateRoute: AppRoutes.onGenerateRoute,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
    );
  }
}
