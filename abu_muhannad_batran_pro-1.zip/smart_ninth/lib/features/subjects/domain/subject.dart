class Subject {
  final String name;
  final String icon;
  final int colorValue;

  const Subject({required this.name, required this.icon, required this.colorValue});
}
