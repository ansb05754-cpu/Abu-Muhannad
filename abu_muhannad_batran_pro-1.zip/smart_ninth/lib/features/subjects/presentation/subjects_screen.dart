import 'package:flutter/material.dart';
import '../../../app/routes.dart';
import '../../../app/theme.dart';
import '../../../core/database/subject_data.dart';
import '../../../features/subjects/domain/subject.dart';

class SubjectsScreen extends StatefulWidget {
  const SubjectsScreen({super.key});
  @override
  State<SubjectsScreen> createState() => _SubjectsScreenState();
}

class _SubjectsScreenState extends State<SubjectsScreen> {
  String query = '';

  IconData _iconFor(String name) {
    switch (name) {
      case 'calculate': return Icons.calculate_rounded;
      case 'shapes': return Icons.category_rounded;
      case 'menu_book': return Icons.menu_book_rounded;
      case 'language': return Icons.translate_rounded;
      case 'science': return Icons.science_rounded;
      case 'biotech': return Icons.biotech_rounded;
      case 'history_edu': return Icons.history_edu_rounded;
      default: return Icons.public_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final filtered = subjects.where((s) => s.name.toLowerCase().contains(query.trim().toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('المواد الدراسية')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 18, 16, 12), child: TextField(
          textDirection: TextDirection.rtl,
          onChanged: (value) => setState(() => query = value),
          decoration: const InputDecoration(hintText: 'ابحث عن مادة دراسية...', prefixIcon: Icon(Icons.search_rounded), contentPadding: EdgeInsets.symmetric(vertical: 15)),
        )),
        Padding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 12), child: Row(children: [
          const Expanded(child: Text('مواد الصف التاسع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppTheme.navy))),
          Text('${filtered.length} مواد', style: const TextStyle(color: AppTheme.muted, fontSize: 12)),
        ])),
        Expanded(child: filtered.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.search_off_rounded, size: 48, color: AppTheme.muted), SizedBox(height: 10), Text('ما لقينا مادة بهذا الاسم')]))
          : GridView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 22),
            itemCount: filtered.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .94),
            itemBuilder: (context, index) {
              final Subject subject = filtered[index];
              final color = Color(subject.colorValue);
              return Card(clipBehavior: Clip.antiAlias, child: InkWell(
                onTap: () => Navigator.pushNamed(context, AppRoutes.lessons, arguments: subject.name),
                child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(width: 55, height: 55, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(17)), child: Icon(_iconFor(subject.icon), color: color, size: 30)),
                  const SizedBox(height: 17),
                  Text(subject.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: AppTheme.navy), maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 8),
                  Row(children: [const Expanded(child: Text('فتح المادة', style: TextStyle(fontSize: 12, color: AppTheme.muted))), Icon(Icons.arrow_back_rounded, size: 16, color: color)]),
                ])),
              ));
            },
          )),
      ]),
    );
  }
}
