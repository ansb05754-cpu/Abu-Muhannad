import 'package:flutter/material.dart';
import '../../../app/theme.dart';

class LessonsScreen extends StatelessWidget {
  final String subjectName;
  const LessonsScreen({super.key, required this.subjectName});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(subjectName)),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppTheme.navy, AppTheme.teal], begin: Alignment.topRight, end: Alignment.bottomLeft),
        borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.auto_stories_rounded, color: Colors.white, size: 38), const SizedBox(height: 17),
          const Text('رحلتك في المادة', style: TextStyle(color: Colors.white70, fontSize: 14)), const SizedBox(height: 7),
          Text(subjectName, style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10), const Text('تعلّم المفاهيم، راجع الملخصات، واختبر فهمك.', style: TextStyle(color: Colors.white70, height: 1.6)),
        ]),
      ),
      const SizedBox(height: 24),
      const Text('أقسام المادة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppTheme.navy)),
      const SizedBox(height: 13),
      const _ContentCard(icon: Icons.menu_book_rounded, title: 'الدروس والشروحات', subtitle: 'ترتيب الدروس حسب فهرس الكتاب', color: AppTheme.teal),
      const SizedBox(height: 11),
      const _ContentCard(icon: Icons.summarize_rounded, title: 'الملخصات', subtitle: 'مراجعة أهم الأفكار والمفاهيم', color: Color(0xFF7B61A8)),
      const SizedBox(height: 11),
      const _ContentCard(icon: Icons.quiz_rounded, title: 'الأسئلة والاختبارات', subtitle: 'تدرّب على أسئلة تساعدك على الاستعداد', color: Color(0xFFB7791F)),
      const SizedBox(height: 20),
      Container(padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: const Color(0xFFEAF5F3), borderRadius: BorderRadius.circular(18)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.info_outline_rounded, color: AppTheme.teal), SizedBox(width: 11), Expanded(child: Text('الواجهة جاهزة لاستقبال المحتوى التعليمي. يلزم إضافة الدروس والملخصات والأسئلة المعتمدة قبل نشر التطبيق.', style: TextStyle(color: AppTheme.navy, height: 1.7, fontSize: 13))),
      ])),
      const SizedBox(height: 20),
      OutlinedButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_forward_rounded), label: const Text('العودة إلى المواد'),
        style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)))),
    ]),
  );
}

class _ContentCard extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final Color color;
  const _ContentCard({required this.icon, required this.title, required this.subtitle, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8EDF2))),
    child: Row(children: [Container(width: 46, height: 46, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: color)),
      const SizedBox(width: 13), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)), const SizedBox(height: 5), Text(subtitle, style: const TextStyle(fontSize: 12, color: AppTheme.muted, height: 1.5))])),
      const Icon(Icons.chevron_left_rounded, color: AppTheme.muted),
    ]),
  );
}
