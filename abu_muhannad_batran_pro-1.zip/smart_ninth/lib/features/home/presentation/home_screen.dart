import 'package:flutter/material.dart';
import '../../../app/routes.dart';
import '../../../core/constants/app_constants.dart';
import '../../../app/theme.dart';
import '../../../core/database/subject_data.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName, style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(padding: const EdgeInsetsDirectional.only(end: 16),
            child: CircleAvatar(backgroundColor: Colors.white.withValues(alpha: .14),
              child: const Icon(Icons.school_rounded, color: Colors.white))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(23),
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft,
                colors: [AppTheme.navy, Color(0xFF205B70), AppTheme.teal]),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [BoxShadow(color: AppTheme.navy.withValues(alpha: .17), blurRadius: 22, offset: const Offset(0, 10))],
            ),
            child: Stack(children: [
              PositionedDirectional(end: -10, top: -8, child: Icon(Icons.auto_stories_rounded, size: 112, color: Colors.white.withValues(alpha: .08))),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(30)),
                  child: const Text(AppConstants.gradeName, style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
                const SizedBox(height: 20),
                const Text('مستقبلك يبدأ\nبخطوة اليوم ✨', style: TextStyle(color: Colors.white, fontSize: 29, height: 1.35, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                const Text('تعلّم، راجع، وتقدّم بثقة. كل رحلتك الدراسية في مكان واحد.',
                  style: TextStyle(color: Colors.white70, height: 1.7, fontSize: 14)),
                const SizedBox(height: 21),
                FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppTheme.navy,
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                  onPressed: () => Navigator.pushNamed(context, AppRoutes.subjects),
                  icon: const Icon(Icons.arrow_back_rounded), label: const Text('ابدأ التعلّم', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ]),
            ]),
          ),
          const SizedBox(height: 26),
          Row(children: [
            const Expanded(child: Text('مساحتك الدراسية', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppTheme.navy))),
            Text('${subjects.length} مواد', style: const TextStyle(color: AppTheme.teal, fontWeight: FontWeight.bold)),
          ]),
          const SizedBox(height: 13),
          Row(children: [
            Expanded(child: _QuickStat(icon: Icons.menu_book_rounded, value: '${subjects.length}', label: 'مواد دراسية', color: AppTheme.teal)),
            const SizedBox(width: 12),
            const Expanded(child: _QuickStat(icon: Icons.track_changes_rounded, value: 'خطوة بخطوة', label: 'نحو التفوّق', color: Color(0xFFB7791F))),
          ]),
          const SizedBox(height: 27),
          const Text('ماذا تريد أن تدرس؟', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppTheme.navy)),
          const SizedBox(height: 6),
          const Text('اختر المادة للوصول إلى صفحة الدروس والمراجعة.', style: TextStyle(color: AppTheme.muted, height: 1.6)),
          const SizedBox(height: 14),
          ...subjects.take(4).map((subject) {
            final color = Color(subject.colorValue);
            return Padding(padding: const EdgeInsets.only(bottom: 10), child: Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                leading: Container(width: 48, height: 48, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(15)),
                  child: Icon(_iconFor(subject.icon), color: color, size: 26)),
                title: Text(subject.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                subtitle: const Padding(padding: EdgeInsets.only(top: 5), child: Text('اكتشف محتوى المادة', style: TextStyle(fontSize: 12))),
                trailing: const Icon(Icons.chevron_left_rounded, color: AppTheme.muted),
                onTap: () => Navigator.pushNamed(context, AppRoutes.lessons, arguments: subject.name),
              ),
            ));
          }),
          OutlinedButton.icon(onPressed: () => Navigator.pushNamed(context, AppRoutes.subjects),
            icon: const Icon(Icons.grid_view_rounded), label: const Text('عرض جميع المواد'),
            style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)))),
          const SizedBox(height: 22),
          const Center(child: Text('صُنع بشغف لرحلة تعليمية أفضل', style: TextStyle(color: AppTheme.muted, fontSize: 12))),
        ],
      ),
    );
  }

  static IconData _iconFor(String name) {
    switch (name) {
      case 'calculate': return Icons.calculate_rounded;
      case 'shapes': return Icons.category_rounded;
      case 'menu_book': return Icons.menu_book_rounded;
      case 'language': return Icons.translate_rounded;
      case 'science': return Icons.science_rounded;
      case 'biotech': return Icons.biotech_rounded;
      case 'history_edu': return Icons.history_edu_rounded;
      default: return Icons.public_rounded;
    }
  }
}

class _QuickStat extends StatelessWidget {
  final IconData icon; final String value; final String label; final Color color;
  const _QuickStat({required this.icon, required this.value, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE8EDF2))),
    child: Row(children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: color)),
      const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.navy, fontSize: 14)),
        const SizedBox(height: 3), Text(label, style: const TextStyle(color: AppTheme.muted, fontSize: 11)),
      ])),
    ]),
  );
}
